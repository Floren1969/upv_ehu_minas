
# JUPYTER NoteBook-en berezitasunak

**Para ponerte en una celda el formato Markdown dar tecla Esc+M que curioso**

Para escribir codigo de Python en una Celda y poder ejecutarla se usa el tipo de celda Code y debes de dar Shift+Enter para ejecutarla o Ctrol+Enter


```python
a=1;b=1
a+b
```




    2



Si quieres recuperar  el output en cualquier momento debes de poner _numeroCelda, por ejemplo


```python
_10
```




    2



Puedes poner en una celda código de latex ($$ o \$\$ \$\$ ) o tipo de letra, negrita etc pero el tipo de celda es MarkDown.

Si quieres poner texto sólo el tipo sería RawNBConvert

Para hacer capitulos secciones etc de manera automatizada tenemos: #primer nivel ##segundonivel etc #####.....## nesimo nivel

Sobre una celda de tipo code puedes hacer tabulador y te desplegará los comandos y variables que tengas en el Notebook

Esta celda es de tipo Markdown y entonces se pueden hacer muchas cosas:
**Negrita** o __Negrita__
*Italica* o _Italica_
**Negrita y luego _Italica_**

Para marcar con una vertical a izquierda de texto y hace un salto de parrafo antes y despues
>Pepe

Para marcar un códido como literal uso las comillas `print()` comando
>Juan

Para que sea unos codigos en distintas lineas usas ```    ```` y salta parrafo :
```
git uno
goit dos
git tres
```
sigo por aquí

Puedes hacer que ponga código de Mathematica de una manera muy simple con ```nombreprograma
```mathematica
Plot[x,{x,0,1}]
```

Puedo hacer código python:
```python
def f(x):
    return(x)
```


```python
Para que el el texto aparezca literal pones <pre>....</pre> en formato Markdown
```

<pre>
```python
print("Hello World")
```

```javascript
console.log("Hello World")
```
</pre>

y obtienes:

```python
print("Hello World")
```

```javascript
console.log("Hello World")
```

You can add horizontal rules poniendo ---:

---

Para links que te lleven a urls usas []()
Así la pagina de la uni es: [upv](hpp:\\www.ehu.eus)

And shorthand for links:

[IPython's website](http://ipython.org)

You can build nested itemized or enumerated lists:

* One
    - Sublist
        - This
  - Sublist
        - That
        - The other thing
* Two
  - Sublist
* Three
  - Sublist

Now another list:

1. Here we go
    1. Sublist
    2. Sublist
2. There we go
3. Now this

Para las lista antepone * o - y se pueden anidar
 * Uno
 * Dos
 * Tres

- Uno
- Dos
- Tres

Si quieres numeros pues lo pones:
1. Uno
2. Dos
3. Tres
    * cambio 1
    * cambio 2
    * cambio 3
    

Texto resaltado `para resaltar`. Lo siguiente mantiene el esquema resaltado

```
git status
git add
git commit
```


**Puedes hacer tablas en codigo HTML muy fácil**


<table>
<tr>
<th>Header 1</th>
<th>Header 2</th>
</tr>
<tr>
<td>row 1, cell 1</td>
<td>row 1, cell 2</td>
</tr>
<tr>
<td>row 2, cell 1</td>
<td>row 2, cell 2</td>
</tr>
</table>

You can embed code meant for illustration instead of execution in Python:

    def f(x):
        """a docstring"""
        return x**2

or other languages:

    if (i=0; i<n; i++) {
      printf("hello %d\n", i);
      x += 4;
    }

Primer nivel
============

Segundo nivel
-------------

> blockquote

<h1>A First Level Header</h1>

<h2>A Second Level Header</h2>

<p>Now is the time for all good men to come to
the aid of their country. This is just a
regular paragraph.</p>

<p>The quick brown fox jumped over the lazy
dog's back.</p>

<h3>Header 3</h3>

<blockquote>
    <p>This is a blockquote.</p>

    <p>This is the second paragraph in the blockquote.</p>

    <h2>This is an H2 in a blockquote</h2>
</blockquote>


<ul>
<li>Candy.</li>
<li>Gum.</li>
<li>Booze.</li>
</ul>


<ol>
<li>Red</li>
<li>Green</li>
<li>Blue</li>
</ol>


<ul>
<li><p>A list item.</p>
<p>With multiple paragraphs.</p></li>
<li><p>Another item in the list.</p></li>
</ul>


This is an [example link](http://example.com/).

Puedes poner emoticonos entre :laughing: que lo encuentras en http://www.emoji-cheat-sheet.com/

This is an [example link](http://example.com/ "With a Title").

<p>This is an <a href="http://example.com/" title="With a Title">
example link</a>.</p>


<p>I get 10 times more traffic from <a href="http://google.com/"
title="Google">Google</a> than from <a href="http://search.yahoo.com/"
title="Yahoo Search">Yahoo</a> or <a href="http://search.msn.com/"
title="MSN Search">MSN</a>.</p>


I get 10 times more traffic from [Google][1] than from
[Yahoo][2] or [MSN][3].

[1]: http://google.com/        "Google"
[2]: http://search.yahoo.com/  "Yahoo Search"
[3]: http://search.msn.com/    "MSN Search

<p>I start my morning with a cup of coffee and
<a href="http://www.nytimes.com/">The New York Times</a>.</p>

Usando % puedes ejecutar comando que son propios de ipython y que miras en internet

```python
%pwd
```




    'C:\\Users\\mapgaurf\\Documents'




```python
%ls
```

     El volumen de la unidad C es SISTEMA
     El n£mero de serie del volumen es: AAB4-DC8D
    
     Directorio de C:\Users\mapgaurf\Documents
    
    12/04/2016  11:48    <DIR>          .
    12/04/2016  11:48    <DIR>          ..
    11/04/2016  11:45    <DIR>          .ipynb_checkpoints
    02/03/2016  13:49                 0 .Rhistory
    12/04/2016  11:48             7.740 IniciosConElNoteBook.ipynb
    16/10/2013  12:29    <DIR>          MediaHub
    14/03/2016  11:07    <DIR>          Python Scripts
    02/03/2016  10:43    <DIR>          R
    12/04/2016  11:23           103.165 rana.png
    11/03/2016  12:50         2.695.965 TutorialPython3.pdf
    11/04/2016  11:36                 0 untitled.txt
    02/03/2016  10:41    <DIR>          Wolfram Mathematica
                   5 archivos      2.806.870 bytes
                   7 dirs  87.435.677.696 bytes libres
    


```python
Insertar una imagen:
```

<img src="Rana.png" alt="alt text" title="Title" />


Lo siguiente es para acceder a **cosas mágicas del Notebook de Jupiter**: Desde el estilo de celda Code % se usa para una sola linea mágica y %% para varias lineas mágicas


```python
%lsmagic
```




    Available line magics:
    %alias  %alias_magic  %autocall  %automagic  %autosave  %bookmark  %cd  %clear  %cls  %colors  %config  %connect_info  %copy  %ddir  %debug  %dhist  %dirs  %doctest_mode  %echo  %ed  %edit  %env  %gui  %hist  %history  %install_default_config  %install_ext  %install_profiles  %killbgscripts  %ldir  %less  %load  %load_ext  %loadpy  %logoff  %logon  %logstart  %logstate  %logstop  %ls  %lsmagic  %macro  %magic  %matplotlib  %mkdir  %more  %notebook  %page  %pastebin  %pdb  %pdef  %pdoc  %pfile  %pinfo  %pinfo2  %popd  %pprint  %precision  %profile  %prun  %psearch  %psource  %pushd  %pwd  %pycat  %pylab  %qtconsole  %quickref  %recall  %rehashx  %reload_ext  %ren  %rep  %rerun  %reset  %reset_selective  %rmdir  %run  %save  %sc  %set_env  %store  %sx  %system  %tb  %time  %timeit  %unalias  %unload_ext  %who  %who_ls  %whos  %xdel  %xmode
    
    Available cell magics:
    %%!  %%HTML  %%SVG  %%bash  %%capture  %%cmd  %%debug  %%file  %%html  %%javascript  %%latex  %%perl  %%prun  %%pypy  %%python  %%python2  %%python3  %%ruby  %%script  %%sh  %%svg  %%sx  %%system  %%time  %%timeit  %%writefile
    
    Automagic is ON, % prefix IS NOT needed for line magics.



por ejemplo lo siguiente es para que saque el output como Latex


```python
from numpy import*
from sympy import*
```


```python
init_printing()
```


```python
x=Symbol('x')
y=Symbol('y')
(sin(x))/(x**2)
```




$$\frac{1}{x^{2}} \sin{\left (x \right )}$$




```python
%%latex
$\dfrac{\sin(x)}{\cos(x)}$
```


$\dfrac{\sin(x)}{\cos(x)}$



```python
%%latex
$$
\phantom{xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}f(x)=\begin{cases}
a x^2-2 & x=0 \\
3x+5 & x<=0 
\end{cases} \phantom{xxxxx}
$$
es la ecuación básica
```


$$
\phantom{xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx}f(x)=\begin{cases}
a x^2-2 & x=0 \\
3x+5 & x<=0 
\end{cases} \phantom{xxxxx}
$$
es la ecuación básica


Courtesy of MathJax, you can include mathematical expressions both inline: 
$e^{i\pi} + 1 = 0$  and displayed:

$$e^x=\sum_{i=0}^\infty \frac{1}{i!}x^i$$


```python
%%HTML
<h1>Esta imagen sí que sale bien</h1>
<center><image src="Rana.png" width=100 height=200></image></center>

```


<h1>Esta imagen sí que sale bien</h1>
<center><image src="Rana.png" width=100 height=200></image></center>



```python
%%HTML
<h1>Este video si que sale bien</h1>
<center><iframe width="400" height="200" src="https://www.youtube.com/embed/ox09Jko1ErM" 
 frameborder="0" allowfullscreen></iframe></center>
```


<h1>Este video si que sale bien</h1>
<center><iframe width="400" height="200" src="https://www.youtube.com/embed/ox09Jko1ErM" 
 frameborder="0" allowfullscreen></iframe></center>


**If you have local files in your Notebook directory**, you can refer to these files in Markdown cells directly:

    [subdirectory/]<filename>

For example, in the images folder, we have the Python logo:

    <img src="../images/python_logo.svg" />

<img src="../images/python_logo.svg" />

and a video with the HTML5 video tag:

    <video controls src="images/animation.m4v" />

<video controls src="images/animation.m4v" />

These do not embed the data into the notebook file, and require that the files exist when you are viewing the notebook.

Lo siguiente la verdad es que guarda un fichero pero lo veo como html


```python
%%writefile lecturaescritura.txt
esta es la primera linea
23
esta es la tercera linea
-56 pies
esta es la última línea
```

    Writing lecturaescritura.txt
    

Si quieres **descargar un fichero de Dropbox** puedes hacer lo siguiente: Se generará un link y luego con botón derecho abrir nueva pestaña y te dirige al dropbox donde lo puedes descargar.


```python
%%HTML
<a href="https://www.dropbox.com/s/esv0jkqkksaxv6i/Notak1.Partziala.MatematikAplikatua.docx?dl=0" 
 download="fichero">
 Descargar Archivo
</a>

```


<a href="https://www.dropbox.com/s/esv0jkqkksaxv6i/Notak1.Partziala.MatematikAplikatua.docx?dl=0" 
 download="fichero">
 Descargar Archivo
</a>





```python
%matplotlib inline
import matplotlib.pyplot as plt
```


```python
plt.plot([1,2,3])
```




    [<matplotlib.lines.Line2D at 0x809d4a8>]




![png](output_63_1.png)



```python
%reload_ext rpy2.ipython # se pone load_ext pero como lo volvi a cargar pues eso reload
import pandas as pd
```


```python
df1 = pd.DataFrame({"A": [1, 2, 3], "B": [1, 2, 3]})
df2 = pd.DataFrame({"A": [3, 2, 1], "B": [1, 2, 3]})
```


```python
%%R
plot_gg <- function(df) {
    p <- ggplot(data=df) + geom_line(aes(x=A, y=B))
    print(p)
}
```

## Uso bonito de las excepciones


```python
def fibo(n):
    try:
        assert(n>0)
        assert(n<20)
    except AssertionError:
        raise ValueError("valores entre 0 y 20")
    a=0
    b=1
    salida=[]
    for x in range(n):
        salida.append(b)
        a,b=b,a+b
    return salida
    
def main():
    """docstring o documentación de la función"""
    try:
        num=input('sartu un numero majeta \n')
        num=int(num)
        print(fibo(num))
    except ValueError:
        print('has metido un valor incorrecto y debe de estar entre 0 y 20')
        
```


```python
main()
```

    sartu un numero majeta 
    23
    has metido un valor incorrecto y debe de estar entre 0 y 20
    


```python
main()
```

    sartu un numero majeta 
    12
    [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
    


```python
main? # esto es especifico de Ipython y te devuelve informacion de la funcion
```

# VAMOS A DIBUJAR


```python
import scipy as sc
```


```python
import numpy as np
```


```python
%matplotlib inline
```


```python
matplotlib? # ver la ayuda que parece muy interesante
```


```python
from matplotlib import pyplot as plt
```


```python
X=np.linspace(-np.pi,np.pi,256,endpoint=True)
```


```python
X;
```


```python
C,S=np.cos(X),np.sin(X)
```


```python
plt.plot(X,C);plt.plot(X,S);plt.show()
```


![png](output_81_0.png)



```python
plt? # ayuda

```


```python
np.linspace(-1,1,3,endpoint=True)
```




    array([-1.,  0.,  1.])




```python
np.linspace(-4,4,9,endpoint=True)
```




    array([-4., -3., -2., -1.,  0.,  1.,  2.,  3.,  4.])




```python
plt.figure(figsize=(8,6),dpi=80)
plt.subplot(1,1,1)
C,S=np.cos(X),np.sin(X)
plt.plot(X,C,color="blue",linewidth=1,linestyle="-")
plt.plot(X,S,color="red",linewidth=1,linestyle=":")
plt.xlim(-4,4);plt.ylim(-1,1)
plt.xticks([-np.pi,-np.pi/2,0,np.pi/2,np.pi],[r'$-\pi$',r'$-\pi/2$',r'$0$',r'$\pi/2$',r'$\pi$'])
plt.yticks(np.linspace(-1,1,3,endpoint=True))
plt.legend(['$cos(x)$','$sin(x)$'])
plt.show()
```


![png](output_85_0.png)



```python
plt.legend?
```


```python
plt.xlim?
```


```python
ax=plt.gca()
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.spines['bottom'].set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))

```


![png](output_88_0.png)



```python
C,S=np.cos(X),np.sin(X)
plt.plot(X,C,color="blue",linewidth=1,linestyle="-",label="$\cos(x)$")
plt.plot(X,S,color="red",linewidth=1,linestyle=":",label="$\sin(x)$")
plt.legend(loc="upper left")
ax=plt.gca()
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0))
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))

```


![png](output_89_0.png)



```python

```
